// Conversion factors for measurement types
const conversionRates = {
    "Length": {
        "Meter": 1,
        "Kilometer": 1000,
        "Centimeter": 0.01,
        "Millimeter": 0.001,
        "Micrometer": 1e-6,
        "Nanometer": 1e-9,
        "Mile": 1609.34,
        "Yard": 0.9144,
        "Foot": 0.3048,
        "Inch": 0.0254,
        "Nautical Mile": 1852,
        "Light Year": 9.461e15,
        "Parsec": 3.0857e16,
        "Angstrom": 1e-10,
        "Furlong": 201.168
    },
    "Mass": {
        "Kilogram": 1,
        "Gram": 0.001,
        "Milligram": 1e-6,
        "Tonne": 1000,
        "Pound": 0.453592,
        "Ounce": 0.0283495,
        "Stone": 6.35029,
        "Carat": 0.0002,
        "Pennyweight": 0.00155517384,
        "Grain": 6.48e-5,
        "Slug": 14.5939,
        "Atomic Mass Unit": 1.660539e-27,
        "Hectogram": 0.1,
        "Decagram": 0.01,
        "Centigram": 0.0001
    },
    "Time": {
        "Second": 1,
        "Minute": 60,
        "Hour": 3600,
        "Day": 86400,
        "Week": 604800,
        "Month": 2629746,
        "Year": 31556952,
        "Millisecond": 0.001,
        "Microsecond": 1e-6,
        "Nanosecond": 1e-9,
        "Picosecond": 1e-12,
        "Femtosecond": 1e-15,
        "Attosecond": 1e-18,
        "Century": 3155695200,
        "Decade": 315569520
    },
    "Temperature": {
        "Celsius": (temp) => temp,
        "Fahrenheit": (temp) => (temp * 9/5) + 32,
        "Kelvin": (temp) => temp + 273.15,
        "Rankine": (temp) => (temp + 273.15) * 9/5,
        "Delisle": (temp) => (100 - temp) * 3/2,
        "Newton": (temp) => temp * 33/100,
        "Reaumur": (temp) => temp * 4/5,
        "Romer": (temp) => (temp * 21/40) + 7.5,
        "Gas Mark": (temp) => (temp - 2) * 25,
        "Planck": (temp) => temp * 1.416784e-18
    },
    "Area": {
        "Square Meter": 1,
        "Square Kilometer": 1e6,
        "Hectare": 10000,
        "Square Mile": 2.59e6,
        "Acre": 4046.86,
        "Square Yard": 0.836127,
        "Square Foot": 0.092903,
        "Square Inch": 6.4516e-4,
        "Square Centimeter": 1e-4,
        "Square Millimeter": 1e-6,
        "Are": 100,
        "Barn": 1e-28,
        "Square Nautical Mile": 3.429e9,
        "Rood": 1011.71
    },
    "Volume": {
        "Cubic Meter": 1,
        "Liter": 0.001,
        "Milliliter": 1e-6,
        "Cubic Centimeter": 1e-6,
        "Cubic Kilometer": 1e9,
        "Cubic Mile": 4.168e9,
        "Cubic Yard": 0.764555,
        "Cubic Foot": 0.0283168,
        "Cubic Inch": 1.63871e-5,
        "Gallon": 3.78541e-3,
        "Quart": 9.4635e-3,
        "Pint": 1.89271e-2,
        "Cup": 2.36588e-2,
        "Fluid Ounce": 3.785e-5
    },
    "Speed": {
        "Meter/Second": 1,
        "Kilometer/Hour": 1000/3600,
        "Miles/Hour": 1609.34/3600,
        "Feet/Second": 0.3048,
        "Knots": 1852/3600,
        "Mach": 343,
        "Speed of Light": 299792458,
        "Furlong/Second": 201.168,
        "Light Year/Day": 1.057e-5,
        "Speed of Sound": 343,
        "Kilometer/Minute": 1000/60,
        "Meter/Minute": 1/60,
        "Centimeter/Second": 0.01,
        "Centimeter/Minute": 0.0001
    },
    "Force": {
        "Newton": 1,
        "Kilogram Force": 9.80665,
        "Pound Force": 4.44822,
        "Dyne": 1e-5,
        "Ounce Force": 0.2780139,
        "Gram Force": 0.00980665,
        "Ton Force": 9.80665e3,
        "Kilo Newton": 1000,
        "Meganewton": 1e6,
        "Kilopound": 4448.22,
        "Decinewton": 0.1,
        "Centinewton": 0.01,
        "Millinewton": 0.001,
        "Micro newton": 1e-6
    },
    "Energy": {
        "Joule": 1,
        "Kilojoule": 1000,
        "Calorie": 4.184,
        "Kilocalorie": 4184,
        "Electron Volt": 1.60218e-19,
        "Watt Hour": 3600,
        "Kilowatt Hour": 3.6e6,
        "Btu": 1055.06,
        "Therm": 1.055e8,
        "Erg": 1e-7,
        "Foot Pound": 1.35582,
        "Kilojoule/Hour": 0.277778,
        "Megajoule": 1e6,
        "Giga Joule": 1e9
    },
    // Add 10 more types like Pressure, Density, Momentum, etc. 
    // Ensure to follow the same pattern for each one.
};

const measurementTypes = {
    "Length": [
        "Meter", "Kilometer", "Centimeter", "Millimeter", "Micrometer", "Nanometer",
        "Mile", "Yard", "Foot", "Inch", "Nautical Mile", "Light Year", "Parsec",
        "Angstrom", "Furlong"
    ],
    "Mass": [
        "Kilogram", "Gram", "Milligram", "Tonne", "Pound", "Ounce", "Stone",
        "Carat", "Pennyweight", "Grain", "Slug", "Atomic Mass Unit", "Hectogram",
        "Decagram", "Centigram"
    ],
    "Time": [
        "Second", "Minute", "Hour", "Day", "Week", "Month", "Year", "Millisecond",
        "Microsecond", "Nanosecond", "Picosecond", "Femtosecond", "Attosecond",
        "Century", "Decade"
    ],
    "Temperature": [
        "Celsius", "Fahrenheit", "Kelvin", "Rankine", "Delisle", "Newton", "Reaumur",
        "Romer", "Gas Mark", "Planck"
    ],
    "Area": [
        "Square Meter", "Square Kilometer", "Hectare", "Square Mile", "Acre", "Square Yard",
        "Square Foot", "Square Inch", "Square Centimeter", "Square Millimeter", "Are", "Barn",
        "Square Nautical Mile", "Rood"
    ],
    "Volume": [
        "Cubic Meter", "Liter", "Milliliter", "Cubic Centimeter", "Cubic Kilometer", "Cubic Mile",
        "Cubic Yard", "Cubic Foot", "Cubic Inch", "Gallon", "Quart", "Pint", "Cup", "Fluid Ounce"
    ],
    "Speed": [
        "Meter/Second", "Kilometer/Hour", "Miles/Hour", "Feet/Second", "Knots", "Mach",
        "Speed of Light", "Furlong/Second", "Light Year/Day", "Speed of Sound", "Kilometer/Minute",
        "Meter/Minute", "Centimeter/Second", "Centimeter/Minute"
    ],
    "Force": [
        "Newton", "Kilogram Force", "Pound Force", "Dyne", "Ounce Force", "Gram Force", "Ton Force",
        "Kilo Newton", "Meganewton", "Kilopound", "Decinewton", "Centinewton", "Millinewton", "Micro newton"
    ],
    "Energy": [
        "Joule", "Kilojoule", "Calorie", "Kilocalorie", "Electron Volt", "Watt Hour", "Kilowatt Hour",
        "Btu", "Therm", "Erg", "Foot Pound", "Kilojoule/Hour", "Megajoule", "Giga Joule"
    ]
};

// Populate measurement types in dropdown
function loadMeasurementTypes() {
    const measurementSelect = document.getElementById("measurement-type");
    for (let type in measurementTypes) {
        const option = document.createElement("option");
        option.value = type;
        option.textContent = type;
        measurementSelect.appendChild(option);
    }
}

// Update units based on selected measurement type
function updateUnits() {
    const type = document.getElementById("measurement-type").value;
    const fromUnitSelect = document.getElementById("from-unit");
    const toUnitSelect = document.getElementById("to-unit");

    // Clear previous units
    fromUnitSelect.innerHTML = "";
    toUnitSelect.innerHTML = "";

    const units = measurementTypes[type];
    units.forEach(unit => {
        const fromOption = document.createElement("option");
        fromOption.value = unit;
        fromOption.textContent = unit;
        fromUnitSelect.appendChild(fromOption);

        const toOption = document.createElement("option");
        toOption.value = unit;
        toOption.textContent = unit;
        toUnitSelect.appendChild(toOption);
    });
}

// Conversion logic
function convert() {
    const fromUnit = document.getElementById("from-unit").value;
    const toUnit = document.getElementById("to-unit").value;
    const value = parseFloat(document.getElementById("value").value);

    if (isNaN(value)) {
        alert("Please enter a valid number.");
        return;
    }

    const type = document.getElementById("measurement-type").value;
    const fromUnitRate = conversionRates[type][fromUnit];
    const toUnitRate = conversionRates[type][toUnit];

    let convertedValue;

    if (type === "Temperature") {
        // Special handling for temperature
        convertedValue = conversionRates[type][toUnit](value);
    } else {
        // General conversion for other types
        convertedValue = (value * fromUnitRate) / toUnitRate;
    }

    document.getElementById("result").textContent = `Converted result: ${convertedValue.toFixed(4)}`;
}

// Save conversion history
function saveHistory() {
    const fromUnit = document.getElementById("from-unit").value;
    const toUnit = document.getElementById("to-unit").value;
    const value = document.getElementById("value").value;
    const result = document.getElementById("result").textContent;

    if (!value || !result) {
        alert("Please perform a conversion first!");
        return;
    }

    const entry = {
        fromUnit: fromUnit,
        toUnit: toUnit,
        value: value,
        result: result,
        timestamp: new Date().toLocaleString()
    };

    let history = JSON.parse(localStorage.getItem("history")) || [];
    history.unshift(entry);
    localStorage.setItem("history", JSON.stringify(history));
    updateHistory();
}

// Load and display history
function updateHistory() {
    const history = JSON.parse(localStorage.getItem("history")) || [];
    const historyList = document.getElementById("history");
    historyList.innerHTML = "";

    history.forEach(entry => {
        const li = document.createElement("li");
        li.textContent = `${entry.timestamp}: ${entry.value} ${entry.fromUnit} → ${entry.result}`;
        historyList.appendChild(li);
    });
}

// Navigation functions
function goToConversionPage() {
    document.getElementById("home-page").style.display = "none";
    document.getElementById("conversion-page").style.display = "block";
    loadMeasurementTypes();
}

function goToHomePage() {
    document.getElementById("conversion-page").style.display = "none";
    document.getElementById("home-page").style.display = "flex";
}

window.onload = function() {
    loadMeasurementTypes();
    updateHistory();
};
